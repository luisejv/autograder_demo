import random
x=input("Ingrese nobre del usuario: ")
y=input("Ingrese preferencia (Especial o numeros): ")

def cambio(x,y):
    w = len(x)
    k=random.randrange(10)
    lista=[]
    for i in x:
        lista.append(i)
    if y=="especial":
        for j in range(w):
            print(lista[j],end="@")
    if y=="numeros":
        for l in range(w):
            print(lista[l],end=k)
    if y=="":
        for n in range(w):
            print(lista[n],end=k)
p = cambio(x,y)
print("Su nombre sera:",p)


