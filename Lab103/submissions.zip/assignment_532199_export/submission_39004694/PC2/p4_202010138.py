from random import randint
def imprimirmatriz(matriz):
    nfilas= len(matriz)
    ncolumnas= len(matriz[0])
    for i in range(nfilas):
        for j in range(ncolumnas):
            print(matriz[i][j],end="\t")
        print("\n")


m=int(input("Ingrese numero de filas:" ))
n=int(input("Ingrese numero de columnas:" ))
filas=[]
for i in range(m):
    columnas=[]
    for j in range (n):
        num=randint(1,10)
        columnas.append(num)
        filas.append(columnas)


