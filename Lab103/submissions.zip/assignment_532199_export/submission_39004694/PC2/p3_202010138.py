from random import randint
numero=1
numero_i=5
filasn=[ ]
for i in range(numero):
    print("Lista de numeros:")
    listan=[ ]
    for j in range(numero_i):
        cantidadn= int(input("Ingrese valor para la lista de numeros:"))
        listan.append(cantidadn)
        filasn.append(listan)
aux=1
auxi=5

filaaux=[]
for i in range(aux):
    print("Lista de palabras: ")
    listaaux=[]
    for j in range(auxi):
        caux=input("Ingrese valor para lista de palabras: " )
        listaaux.append(caux)
        filaaux.append(listaaux)
print("Numeros:",listan)
print("Palabras:",listaaux)

