def contarn(x):
    suman=0
    listanu=[1,2,3,4,5,6,7,8,9,0]
    for i in x:
        if i in listanu:
            suman +=1
    return suman
def suman(x):
    listanu = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    SUMA=0
    for i in x:
        if i in listanu:
            SUMA +=i
    return SUMA

def contarM(x):
    sumaM = 0
    listaM=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","Ñ","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    for i in x:
        if i in listaM:
            sumaM += 1
    return sumaM
def contaru(x):
    Sumau = 0
    listam=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","ñ","o","p","q","r","s","t","u","v","w","x","y","z"]
    for i in x:
        if i in listam:
            Sumau += 1
    return Sumau
def contarcara(x):
    Sumac = 0
    caracteres = ["!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "-", "_",'"',"'","."]
    for i in x:
        if i in caracteres:
            Sumac +=1
    return Sumac

x=input("Ingrese frase: ")
print("Frase:","'",x,"'")
print("Mayusculas:", contarM(x))
print("Minusculas:", contaru(x))
print("Caracteres especiales:",contarcara(x))
print("Suma de numeros:", suman(x))
print("String numeros:", len(x))

