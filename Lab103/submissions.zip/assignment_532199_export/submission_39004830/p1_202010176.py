frase = str(input("Ingrese frase:"))
print("Frase:",frase)
numeros = ["0","1","2","3","4","5","6","7","8","9"]
numeros=0
especiales=0
mayus=0
minus=0

for letra in frase:
    if letra== " " or letra=="@" or letra==".":
        especiales+=1
    if letra in frase.upper():
        mayus+=1
    if letra in frase.lower():
        minus+=1


print("Mayúsculas: ",mayus)
print("Minúsculas: ",minus)
print("Caracteres especiales: ",especiales)
print("Suma números:")
print("String números:")
