numeros=[]
palabras=[]
tamaño_num=[]
pal="a"

for i in range(1,6,1):
    num = int(input("Ingrese valor para lista numeros:"))
    numeros.append(num)
for j in range(1,6,1):
    if len(pal) <= 9:
        pal=str(input("Ingrese valor para lista palabras:"))
        palabras.append(pal)
print(numeros)
print(palabras)


