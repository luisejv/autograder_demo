from random import randint

def func(nombre,pref):
    nuevo_nombre=""
    if pref=="especial":
        nuevo_nombre = "@".join(nombre)
    if pref=="numeros":
        for i in range(len(nombre)):
            print(nombre[i] + str(randint(0, 10)),end="")
    print(nuevo_nombre)

nombre= str(input("Ingrese nombre del usuario:"))
pref= str(input("Ingrese preferencia (especial o numeros):"))

func(nombre,pref)