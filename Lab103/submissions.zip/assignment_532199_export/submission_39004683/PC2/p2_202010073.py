import random
def nombre (a, b):
    if b==str("numero") or b=="" :
        c=len(a)
        r=""
        for i in range (0, c):
           e=a[i]
           d=random.randint(0, 10)
           r=r+str(e)+str(d)
        print ("Su nombre es: "+str(r))

    else :
        c = len(a)
        r=""
        for i in range(0, c):
            e = a[i]
            r=r+str(e)+"@"
        print("Su nombre es: "+str(r))

x=str(input("Ingrese el nombre del usuario: "))
y=str(input("Ingrese su preferencia (numero o especial): "))
nombre(x,y)





