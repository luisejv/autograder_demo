numero=[]
palabra=[]
tamaño_numeros=[]
tamaño_palabra=[]
for i in range (0, 5):
    a=str(input("Ingrese un numero: "))
    if len(a)>3:
        a=str(input("Por favor ingrese un numero valido: "))
    else:
        numero.append(a)
        tamaño_numeros.append(len(a))
for j in range(0, 5):
    b =str(input("Ingrese una palabra: "))
    if len(b) > 9:
        a = str(input("Por favor ingrese una palabra valida: "))
    else:
        palabra.append(b)
        tamaño_palabra.append(len(b))
print("Numeros: "+str(numero))
print("Palabras: "+str(palabra))
print("Tamaño numeros: "+str(tamaño_numeros))
print("Tamaño palabras: "+str(tamaño_palabra))
z=tamaño_numeros.count(max(tamaño_numeros))
for k in range (0, z):
    tamaño_numeros.remove(max(tamaño_numeros))
p=tamaño_palabra.count(max(tamaño_palabra))
for y in range(0, p):

    tamaño_palabra.remove(max(tamaño_palabra))
print("Tamaños: "+str(tamaño_numeros)+str(tamaño_palabra))


