x=str(input("Ingrese una frase: "))
mayuscula=0
minuscula=0
numero=0
strin=""
especial=0
for i in range (0, len(x)):
    caracter=x[i]
    if caracter.isupper()==True:
        mayuscula=mayuscula+1
    elif caracter.islower()==True:
        minuscula=minuscula+1
    elif caracter.isnumeric()==True:
        numero=numero+int(caracter)
        strin=strin+str(caracter)
    else:
        especial=especial+1
print("Mayusculas: "+str(mayuscula))
print("Minusciulas: "+str(minuscula))
print("Caracter especiales: "+str(especial))
print("Suma numeros: "+str(numero))
print("String de numeros: "+str(strin))