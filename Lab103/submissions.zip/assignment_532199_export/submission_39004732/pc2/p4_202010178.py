from random import randint

def generar_matriz (n,m,Elemento="a") :
    matriz = []
    lista = []
    for j in range(0, n):
        lista.clear()
        for i in range (0,m) :
            lista.append(Elemento)
        matriz.append(lista)
    for k in range (0,n):
        print(matriz[k])
        print(" ")
    return matriz


n = int(input("Número de Filas: "))
m = int(input("Número de Columnas: "))
elemento = randint(0,9)
generar_matriz(n,m,elemento)