from random import randint

def nombre_de_usuario(nombre, preferencia) :
    caracteres_nombre = []
    numero = []
    usuario = []
    for j in nombre:
        caracteres_nombre.append(j)
    if preferencia == preferencias[0] :
        for i in range(0,nombre-1) :
            numero.append(randint(0,9))
        for a in range (0,len(caracteres_nombre)) :
            usuario.append(caracteres_nombre[a])
            usuario.append(numero[a])
        for r in usuario :
            print(r,end="")
    if preferencia == preferencias[1] :
        for l in range(0,nombre-1) :
            numero.append("@")
        for b in range (0,len(caracteres_nombre[0])) :
            usuario.append(caracteres_nombre[b])
            usuario.append(numero[b])
        for r in usuario :
            print(r,end="")
        return usuario



preferencias = ["numeros","especial"]
nombre = input("Ingrese nombre del usuario: ")
preferencia = input("Ingrese preferencia ( especial o numeros ): ")

print(nombre_de_usuario(nombre,preferencias))

