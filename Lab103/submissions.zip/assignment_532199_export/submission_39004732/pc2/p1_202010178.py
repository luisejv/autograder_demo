frase = input("Ingrese frase: ")
caracteres = []
numeros = ["0","1","2","3","4","5","6","7","8","9"]
min = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
mayus = []
for k in min:
    mayus.append(k.upper())

for i in range(0,len(frase)) :
    caracteres.append(frase[i])

minusculas = []
mayusculas = []
numbers = []
caracteres_especiales = []

for j in caracteres :
    if j in min :
        minusculas.append(j)
    elif j in mayus :
        mayusculas.append(j)
    elif j in numeros :
        numbers.append(int(j))
    else :
        caracteres_especiales.append(j)
suma = 0
for l in numbers :
    suma = suma + l



print("Mayusculas: ",len(mayusculas))
print("Minusculas: ",len(minusculas))
print("Caracteres especiales: ",len(caracteres_especiales))
print("Suma numeros: ",suma)
print("String numeros: ",end="")
for h in numbers:
    print(h, end="")




