def funcion (numeros,palabras):
    Tamaño_de_numeros = []
    Tamaño_de_palabras = []
    for a in numeros :
        Tamaño_de_numeros.append(len(a))
    print("Tamaño numeros: ",Tamaño_de_numeros)
    for b in palabras :
        Tamaño_de_palabras.append(len(b))
    print("Tamaño palabras: ",Tamaño_de_palabras)
    lista_tamaño = Tamaño_de_numeros + Tamaño_de_palabras
    return print("Lista Tamaño: ",lista_tamaño)


numeros = []
palabras = []
for i in range (5) :
    numero = input("Ingrese valor para lista numeros (hasta 3 digitos): ")
    numeros.append(numero)
for j in range (5) :
    palabra = input("Ingrese valor para lista palabras (hasta 9 caracteres): ")
    palabras.append(palabra)
print("Numeros: ",numeros)
print("Palabras: ",palabras)

funcion(numeros,palabras)