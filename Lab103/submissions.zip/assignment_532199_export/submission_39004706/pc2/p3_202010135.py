def funcion():
    tam_n=[]
    for i in numeros:
        if i<10:
            tam=1
            tam_n.append(tam)
        elif 10<=i<100:
            tam=2
            tam_n.append(tam)
        elif 100<=i<1000:
            tam=3
            tam_n.append(tam)
    print("Tamaño numeros: ",tam_n)
    tam_p=[]
    for i in range(len(palabras)):
            len(str(i)[i])==tam
            tam_p.append(tam)
    print("Tamaño palabras: ",tam_p)

numeros=[]
palabras=[]
for i in range(5):
    n=int(input("Ingrese valor para lista números: "))
    numeros.append(int(n))
for i in range (5):
    p=input("Ingrese valor para lista palabras: ")
    palabras.append(p)

print("Números: ",numeros)
print("Palabras: ",palabras)
funcion()



