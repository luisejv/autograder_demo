lista=[]

frase=input("Ingrese frase: " )
lista+=frase

aux=100
suma=0
for i in range(len(lista)):
    if type(i)==type(aux):
        suma+=i


print(lista)
print("Frase: ", frase)
print(suma)