from random import randint
def imprimir(matriz):
    n_filas=len(matriz)
    n_columnas=len(matriz[0])
    for i in range(n_filas):
        for j in range (n_columnas):
            print(matriz[i][j],end='\t')
        print('\n')

numfilas=int(input("Ingrese numero de filas: "))
numcolumnas=int(input("Ingrese numero de columnas: "))

filas=[]
for i in range(numfilas):
    columnas=[]
    for j in range(numcolumnas):
        numero=randint(1,10)
        columnas.append(numero)
    filas.append(columnas)

print("Matriz original:")
print(filas)


