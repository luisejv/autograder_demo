from random import randint

def usuario(nombre,preferencia):
    lista=[nombre]
    if preferencia=="" or preferencia =="numeros":
        contador=0
        while contador<=len(lista):
            for i in range(len(lista)):
                contador+2
            lista.insert(contador,randint(1,10))
        print(lista)
    if preferencia=="especial":
        contador = 0
        while contador <= len(lista):
            for i in range(len(lista)):
                contador + 2
            lista.insert(contador,"@")
        print(lista)
    return(lista)


nombre =input("Ingrese nombre del usuario: ")
preferencia = input("Ingrese preferencias (especiales o números): ")

usuario(nombre,preferencia)
