def printm(matriz):
    i = len(matriz)
    j = len(matriz[0])
    for a in range(i):
        for b in range(j):
            print(matriz[a][b], end='\t')
        print('\n')


matriz = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
num_filas = int(input('Ingrese el numero de filas: '))
num_columnas = int(input('Ingrese el numero de columnas: '))

for a in range(num_filas):
    for b in range(num_columnas):
        printm(matriz)

