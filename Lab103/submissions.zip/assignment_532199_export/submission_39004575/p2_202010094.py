def funcion1(nombre, pref):
    if pref == 'especial':
        print(nombre, '@')
    elif pref == 'numero':
        print(nombre, '7')
    else:
        print('error')


funcion1(str(input('Ingrese su nombre: ')), str(input('Ingrese su preferencia: ')))
