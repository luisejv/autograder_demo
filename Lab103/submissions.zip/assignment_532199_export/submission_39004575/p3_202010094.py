lista1 = []
lista2 = []
while 1:
    a = str(input('Ingrese valor para lista de numeros: '))
    lista1.append(a)
    if len(lista1) == 5:
        break

while 1:
    b = str(input('ingrese valor para lista palabras: '))
    lista2.append(b)
    if len(lista2) == 5:
        break

print('Numeros:', lista1)
print('palabras:', lista2)


