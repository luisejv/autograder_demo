import re
frase = str(input('Ingrese frase: '))
numM = 0
numm = 0
especiales = 0

print('frase :', frase)

frase.split(' ')
partesfrase = re.split(r'[ ,\s]\s*', frase)

for parte in partesfrase:
    print(parte)