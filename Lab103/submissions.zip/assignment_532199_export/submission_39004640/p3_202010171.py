def lista(a):
    a = str(a)
    x = []
    cuenta = 0
    for i in range(len(a)):
        for j in range(len(a[i])):
            j = 1
            cuenta += j
        x.append(cuenta)
        cuenta = 0
    return x


a = 1
b = 1
numeros = []
palabras = []

while a <= 5:
    n = int(input("Ingrese valor para lista numeros: "))
    numeros.append(n)
    a += 1

while b <= 5:
    p = input("Ingrese valor para lista palabras: ")
    palabras.append(p)
    b += 1

print("Numeros:", numeros)
print("Palabras:", palabras)
print("Tamaño numeros:", lista(numeros))
print("Tamaño palabras:", lista(palabras))

cuenta = 0
for i in range(len(numeros)):
    if numeros[i] >= cuenta:
        cuenta = numeros[i]
        numeros[i] = cuenta