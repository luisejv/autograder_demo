a = input("Ingrese frase: ")
mayusculas = 0
minusculas = 0
c_e = 0
suma = 0

for i in range(len(a)):
    if a[i] == a.upper():
        mayusculas += 1
    elif a[i] == a.lower():
        minusculas += 1
    elif a[i] == "1" or "2" or "3" or "4" or "5" or "6" or "7" or "8" or "9":
        suma += 1
    else:
        c_e += 1

print("Mayusculas", mayusculas)
print("Minusculas", minusculas)
print("Caracteres especiales", c_e)
print("Suma numeros", suma)
