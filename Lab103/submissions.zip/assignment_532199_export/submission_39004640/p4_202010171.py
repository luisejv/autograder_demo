from random import randint

n = int(input("Ingrese un numero de filas: "))
m = int(input("Ingrese un numero de columnas: "))

def imprimirmatriz(n, m):
    matriz = [[randint(0, 10) for i in range(m)] for j in range(n)]
    return matriz

print("Matriz original", imprimirmatriz(n, m))
