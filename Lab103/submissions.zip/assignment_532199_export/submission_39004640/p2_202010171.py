from random import randint
a = input("Ingrese el nombre de usuario: ")

def usuario(a):
    x = input("Ingrese preferencia(numeros o especial: ")
    if x == "especial":
        a = "@".join(a)
    elif x == "numeros":
        a = str(randint(0, 10)).join(a)
    return a


print(usuario(a))
