lista=[]
nueva_lista=[]
from random import randint
def usuario(a,b):
    for j in range(0,len(a)):
        lista.append(a[j])
    if b=="especial":
        for i in range(0,len(a)):
            nueva_lista.append("@")
    else:
        for i in range(0,len(a)):
            nueva_lista.append(randint(0,10))
    for t in range(len(lista)):
        nueva_lista.append(lista[t])
    return(nueva_lista)
x=input("Ingrese nombre del usuario: ")
y=input("Ingrese referencia (especial o numeros): ")
resultado=usuario(x,y)
print(resultado)