lista = []
numeros=[]
palabras=[]
def funcion(a):
    for l in lista:
        if a[l]!=str:
            numeros.append(a[l])
        else:
            palabras.append(a[l])
    print(numeros)
    print(palabras)


for i in range(0, 5):
    x = int(input("Ingrese valor para lista numeros: "))
    lista.append(x)
for j in range(0, 5):
    y = input("Ingrese valor para lista palabras: ")
    lista.append(y)
resultado=funcion(lista)
