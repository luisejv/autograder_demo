def matriz_0(a,b):
    matriz=[]
    from random import randint
    for i in range(a):
        elemento_fila = randint(0,9)*b
        matriz.append(elemento_fila)

    for i in range(a):
        for j in range(b):
            print(matriz[i][j],end=" ")
        print()

    for k in range(a):
        for u in range(b):
            if u%2==0:
                matriz[k][u] = "*"
            else:
                matriz[k][u] = "@"
            print(matriz[k][u], end=" ")
        print()

x=int(input("filas: "))
y=int(input("columnas: "))
resultado=matriz_0(x,y)
print(resultado)