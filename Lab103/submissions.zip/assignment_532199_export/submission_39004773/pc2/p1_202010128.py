mayus=0
minus=0
carac_especiales=0
suma_numeros=0
lista=[]
x=input("Ingrese frase: ")
for i in range(0,len(x)):
    if i=="A"or"B"or"C"or"D"or"E"or"F"or"G"or"H"or"I"or"J"or"K"or"L"or"M"or"N"or"O"or"P"or"Q"or"R"or"S"or"T"or"U"or"V"or"W"or"X"or"Y"or"Z":
        mayus+=1
    elif i=="a"or"b"or"c"or"d"or"e"or"f"or"g"or"h"or"i"or"j"or"k"or"l"or"m"or"n"or"o"or"p"or"q"or"r"or"s"or"t"or"u"or"v"or"w"or"x"or"y"or"z":
        minus+=1
    elif x[i]==" "or"@"or".":
        carac_especiales+=1
    elif i>=0 or i<=9:
        lista.append(x[i])
        suma_numeros+=x[i]
print("frase:",x)
print("Mayusculas:",mayus)
print("Minusculas:",minus)
print("Caracteres especiales:",carac_especiales)
print("Suma de numeros",suma_numeros)
print("Strings numeros",lista)