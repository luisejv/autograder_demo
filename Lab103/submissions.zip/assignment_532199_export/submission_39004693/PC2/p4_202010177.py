from random import randint
filas = int(input("Ingrese número de filas: "))
columnas = int(input("Ingrese número de columnas: "))
matriz = [[randint(0,10) for i in range(filas)] for j in range(columnas)]
print("Matriz original: ")
for i in range(filas):
    for j in range(columnas):
        print(matriz[i][j],end=" ")
    print()
print("Matriz final")
for i in range(filas):
    for j in range(columnas):
        if i == j:
            matriz[i][j] = "@"
            print(matriz[i][j],end=" ")
        else:
            matriz[i][j] = "*"
            print(matriz[i][j],end=" ")

