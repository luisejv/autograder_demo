lista_palabras = []
lista_numeros = []
tamano_numeros = []
tamano_palabras = []
for i in range(5):
    numeros = int(input("Ingrese valor para lista numeros: "))
    lista_numeros.append(numeros)
for i in range(5):
    palabras = str(input("Ingrese valor para lista palabras: "))
    lista_palabras.append(palabras)
print(lista_numeros)
print(lista_palabras)
for i in range(len(lista_numeros)):
    tamano_num = len(str(lista_numeros[i]))
    tamano_numeros.append(tamano_num)

for i in range(len(lista_palabras)):
    tamano_pal = len(lista_palabras[i])
    tamano_palabras.append(tamano_pal)
print(tamano_numeros)
print(tamano_palabras)
for i in lista_numeros:
    mayor = 0
    if lista_numeros[i] >mayor:
        mayor = lista_numeros[i]
    lista_numeros.pop(mayor)

for j in range(len(lista_palabras)):
    mayor = 0
    if lista_palabras[j] > mayor:
        mayor = lista_palabras[j]
    lista_numeros.pop()

lista_pal_num = lista_palabras + lista_numeros
print(lista_pal_num)
