frase = str(input("Ingresa frase: "))
print("Frase: ",frase)
minusculas = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","ñ","o","p","q","r","s","t","u","v","w","y","z"]
mayusculas = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","Ñ","O","P","Q","R","S","T","U","V","W","Y","Z",]
numeros = ["0","1","2","3","4","5","6","7","8","9"]
lista_minusculas = []
lista_mayusculas =[]
lista_numeros = []
lista_numeros_string = []
caracteres_especiales = []
for i in range(len(frase)):
    if frase[i] in minusculas:
        lista_minusculas.append(frase[i])
    elif frase[i] in mayusculas:
        lista_mayusculas.append(frase[i])
    elif frase[i] in numeros:
        lista_numeros_string += frase[i]
        lista_numeros.append(int(frase[i]))
    elif frase[i] not in minusculas and frase[i] not in mayusculas and frase[i] not in numeros:
        caracteres_especiales.append(frase[i])
def printear_str_numeros(lista):
    for i in range(len(lista)):
        print(lista[i],end="")


print("Mayúsculas: ",len(lista_mayusculas))
print("Minúsculas: ",len(lista_minusculas))
print("Caracteres especiales: ", len(caracteres_especiales))
print("Suma números:",sum(lista_numeros))
print("String numeros: ",end="")
printear_str_numeros(lista_numeros_string)