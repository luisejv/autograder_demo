from random import randint
def crear_nombre_usuario(nombre,pref):
    if preferencia == "especial":
        for i in range(len(nombre_de_usario)):
            if i == len(nombre_de_usario) - 1:
                print(nombre_de_usario[i])
            else:
                print(nombre_de_usario[i] + "@", end="")

    if preferencia == "numeros":
        for i in range(len(nombre_de_usario)):
            if i == len(nombre_de_usario) - 1:
                print(nombre_de_usario[i])
            else:
                print(nombre_de_usario[i] + str(randint(0, 10)), end="")
nombre_de_usario = str(input("Ingrese nombre de usuario: "))
preferencia = str(input("Ingrese preferencia (especial o numeros): "))

crear_nombre_usuario(nombre_de_usario,preferencia)