import random

y=str(input("Ingrese su nombre: "))
pref=str(input("Ingrese su preferencia: "))
if pref=='especial':
    for i in range(0,len(y),2):
        str(y.insert(('@')))

elif pref=='numeros':
    for i in range(0,len(y),2):
        str(y.insert(random.randint(0,10)))