frase=str(input("Ingrese su frase :" ))
res = [int(i) for i in frase.split() if i.isdigit()]

suma=0
for i in range(len(res)):
    suma+=res[i]
    gege=res[i]
print("Mayusculas : ", sum(1 for g in frase if g.isupper()))
print("Suma numeros:", suma)
print("Minusculas: ", sum(1 for c in frase if c.islower()))
print ("Caracteres especiales: ",sum(frase.count(x) for x in ['[','^','&','$','#',']']))



