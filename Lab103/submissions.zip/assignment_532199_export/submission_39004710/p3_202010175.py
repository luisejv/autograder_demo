list1 = []
for i in range(5):

    x = str(input("Ingrese su numero"))
    if len(x) <= 9:
        list1.append(x)

print("numeros: ", list1)
list2 = []
for j in range(5):
    y = str(input("Ingrese su caracter"))
    if len(y) <= 9:
        list2.append(y)
print("caracteres: ", list2)


def contador(z):
    list3 = []
    for q in range(len(z)):
        a = len(z[q])
        if len(z[q]) <= 9:
            list3.append(a)
    print(list3)


contador(list1)
contador (list2)
