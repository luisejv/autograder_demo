import random

n=int(input("Ingrese su numero de filas:"))
m=int(input("Ingrese numero de columnas"))
list=[]
for i in range(n):
    y=[]
    for j in range(m):
        y.append((random.randint(0,10)))
    list.append(y)
for i in range(n):
    for j in range(m):
        print(list[i][j], end=" ")
    print()

