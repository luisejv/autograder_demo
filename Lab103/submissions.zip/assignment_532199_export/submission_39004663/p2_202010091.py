import random
def nombres():
    n = input("Ingrese nombre: ")
    y = input("Ingrese preferencia: ")
    lista1 = [n]
    m = n.split()
    if y=="numeros":
        m.append(random.randint(1,10))
    if y=="especial":
        m.append("@")
        print(m)
    return m

print(nombres())


