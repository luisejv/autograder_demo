for i in range(1,6):
    n = int(input("Ingrese valor para lista numeros: "))
    lista1 = [n]
    lista1.append(n)
    print(lista1)
for j in range(1,6):
    m = input("Ingrese valor para lista palabras: ")
    lista2 = [m]

