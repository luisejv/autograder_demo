n = input("Ingrese palabra: ")
indice=0
mayusculas=0
minusculas=0
especiales=0
while indice < len(n):
  frase = n[indice]
  if frase.isupper() == True:
    mayusculas += 1
  elif frase.islower() == True:
    minusculas += 1
  indice += 1
  elif frase!=frase.isupper() or frase!=frase.islower():
      especiales +=1

print("mayusculas: " , mayusculas)
print("minusculas: " , minusculas)
print(especiales)