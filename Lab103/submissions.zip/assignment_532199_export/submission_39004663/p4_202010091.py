import random

def matrizAleatoria(n):
    for i in range(len(n)):
        for j in range(len(m)):
            n[i][j] = random.randint(1,10)
    return n
n = int(input("Ingrese numero: "))
m = int(input("Ingrese numero: "))
n = str(n)
m = str(m)