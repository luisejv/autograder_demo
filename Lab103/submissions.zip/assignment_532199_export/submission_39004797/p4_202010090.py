import random
x=int(input('ingrese numero de filas: '))
y= int(input('ingrese numero de columnas: '))
c= []
for i in range(0,x):
    c.append([])
    print(c)
    for n in range (1,y):
        c[i].append(random.randint(0,10))
    print(c)
slice(c)



