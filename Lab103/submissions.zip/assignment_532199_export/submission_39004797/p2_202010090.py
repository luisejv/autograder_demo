def funcion (x,y):
    import random
    if y == 'numeros':
        for i in range(0,len(x)):
            if i % 2 !=0:
                print(1)
                o= random.randint(0,9)
                o= str(o)
                x.replace(x[i], o)
                print(x)

x= input('Ingrese nombre del usuario: ')
y= input ('Ingrese preferencia (especial o numeros): ')
c = funcion(x,y)
