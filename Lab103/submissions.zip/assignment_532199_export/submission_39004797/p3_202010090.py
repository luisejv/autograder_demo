def funcion(c,n):
    ta=[]
    tap=[]
    for i in c:
        if i>99:
            ta.append(3)
        elif i>9:
            ta.append(2)
        else:
            ta.append(1)
    print('Tamano numeros: ',ta)
    for i in n:
        tap.append(n.len(i))
n=[]
c=[]
print(type(c))
for i in range (1,6):
        x= int(input('Ingrese valor para lista numeros: ',))
        while x > 999:
            x = int(input('Ingrese valor para lista numeros: ', ))
        print(x)
        c.append(x)
        print(c)

for i in range (1,6):
    x= input('Ingrese valor para lista palabras: ',)
    while len(x)>9:
        x = input('Ingrese valor para lista palabras: ', )
    print(x)
    n.append(x)
    print(n)
k= funcion(c,n)



