def funcion (x):
    print('Frase: "',x, '"')
    c= 0
    for i in range(0, len(x)):
        q= int(i)
        if x[q] == x.upper[q]:
            print(x[i])
x='Hola me gust@ programar en ICC 1.03'
d = funcion(x)