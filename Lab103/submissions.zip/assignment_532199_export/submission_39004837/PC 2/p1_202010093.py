def contador_minusculas_mayusculas(cadena):
    contador = {'minusculas':0,'mayusculas':0}

    for c in cadena:
        if c.isupper():
            contador['mayusculas'] += 1
        elif c.islower():
            contador['minusculas'] += 1

    return contador


frase = str(input("Ingrese frase: "))
print("Frase:",(frase[0:100]))
print(contador_minusculas_mayusculas(frase))

