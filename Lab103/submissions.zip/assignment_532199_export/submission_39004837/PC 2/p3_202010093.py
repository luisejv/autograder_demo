A = str(input("Ingrese valor para lista números: "))
B = str(input("Ingrese valor para lista números: "))
C = str(input("Ingrese valor para lista números: "))
D = str(input("Ingrese valor para lista números: "))
W = str(input("Ingrese valor para lista palabras: "))
X = str(input("Ingrese valor para lista palabras: "))
Y = str(input("Ingrese valor para lista palabras: "))
Z = str(input("Ingrese valor para lista palabras: "))

print("Números: "(A, B, C, D))
print("Palbras: "(W, X, Y, Z))


