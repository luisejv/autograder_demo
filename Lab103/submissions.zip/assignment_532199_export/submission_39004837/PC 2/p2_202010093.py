def contador_especial_numeros(cadena):
    contador = {'especial':0,'numeros':0}

    for c in cadena:
        if c.isespecial():
            print(nombre)
        elif c.isnumeros():
            print(nombre),231

    return contador
nombre = str(input("Ingrese nombre del usuario: "))
categoría = str(input("Ingrese preferencia: "))
print(contador_especial_numeros(nombre))
print("Su nombre será:", (nombre)(7324))