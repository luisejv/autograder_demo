import random

filas = 0
columnas = 0

def ImprimirMatriz(mat):
    for i in range(filas):
        for j in range(columnas):
            print(mat[i][j], end = " ")
        print()
    print()
def Funcion2(mat):
    cont = 0
    for i in range(filas):
        for j in range(columnas):
            if (i+j)%2 == 0:
                mat2[i][j] = "@"
            else:
                mat2[i][j] = "*"
                cont = cont + 1
    return cont

while(filas <= 1 or columnas <= 1):
    filas = int(input("Ingrese número de filas: "))
    columnas = int(input("Ingrese número de columnas: "))

random_matrix = [[random.randint(0,10) for i in range(columnas)] for j in range(filas)]
mat2 = random_matrix
ImprimirMatriz(random_matrix)
ast = Funcion2(random_matrix)
ImprimirMatriz(mat2)
print(ast)