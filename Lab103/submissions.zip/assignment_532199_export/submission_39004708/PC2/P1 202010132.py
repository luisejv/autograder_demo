z=input("Ingrese una frase: ")
print(z)





















