a=int(input("Ingrese el numero de filas: "))
b=int(input("Ingrese el numero de columnas: "))
print("Matriz original:")
g=[[1,8,1],
   [7,5,2],
   [6,4,3]]
for i in range (len(g)):
    for j in range(len(g)):
        print(g[i][j],end=" ")
    print()
print("Nueva: ")
for i in range (len(g)):
    for j in range(len(g)):
        if (i%2==0 and j%2!=0):
            print("@")
        print(g[i][j],end="")
    print()






