a=int(input("Ingrese el valor para la lista: "))
b=int(input("Ingrese el valor para la lista: "))
c=int(input("Ingrese el valor para la lista: "))
d=int(input("Ingrese el valor para la lista: "))
e=int(input("Ingrese el valor para la lista: "))
f=input("Ingrese la palabra para la lista: ")
g=input("Ingrese la palabra para la lista: ")
h=input("Ingrese la palabra para la lista: ")
i=input("Ingrese la palabra para la lista: ")
j=input("Ingrese la palabra para la lista: ")
lista1=[a,b,c,d,e]
lista2=[f,g,h,i,j]
print(lista1)
print(lista2)
mayor=lista1[0]
for i in lista1:
    if i>mayor:
        mayor=i

print("El mayor de la lista1 es:", mayor)




