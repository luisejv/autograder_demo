a=input("Ingrese el nombre de usuario: ")
b=input("Ingrese preferencia(especial o numeros)")
if (b=="especial"):


elif(b=="numeros"):










