ele1 = input("Ingrese valor para la lista numeros: ")
ele2 = input("Ingrese valor para la lista numeros: ")
ele3 = input("Ingrese valor para la lista numeros: ")
ele4 = input("Ingrese valor para la lista numeros: ")
ele5 = input("Ingrese valor para la lista numeros: ")
let1 = str(input("Ingrese valor para lista palabras: "))
let2 = str(input("Ingrese valor para lista palabras: "))
let3 = str(input("Ingrese valor para lista palabras: "))
let4 = str(input("Ingrese valor para lista palabras: "))
let5 = str(input("Ingrese valor para lista palabras: "))

listan = (ele1, ele2, ele3, ele4, ele5)
listal = (let1, let2, let3, let4, let5)

print("Numeros: ",listan)
print("Palabras", listal)
print("Tamaño numeros: ",len(ele1),",",len(ele2),",",len(ele3),",",len(ele4),",",len(ele5))
print("Tamaño palabras: ",len(let1),",",len(let2),",",len(let3),",",len(let4),",",len(let5))

listan+=listal
mayor = max(listan)
listan.split(mayor)
print(listan)
