def contar(cadena):
    numeros = 0
    minuscu = 0
    mayuscu = 0
    especiales = 0

    for x in cadena:
        if x.isdigit():
            numeros += 1
        elif x.lower():
            minuscu += 1
        elif x.upper():
            mayuscu += 1
        else:
            especiales += 1
    return numeros, minuscu, mayuscu, especiales

texto = input("Ingrese frase: ")
print("Frase: ", texto )
print('Mayusculas:' , x.upper)
print('Minusculas: ', x.lower)
print('Caracteres especiales: ')

