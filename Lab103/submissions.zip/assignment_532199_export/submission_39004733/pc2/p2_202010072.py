from random import randint

nombre = str(input("Ingrese nombre del usuario: "))
preferencia = input("Ingrese preferecia (especial o numeros): ")

if preferencia == "numeros":
    y = nombre.join(randint(0,10))
    print(y)
elif preferencia == "especial":
    x = nombre.join("@")
    print(x)
