n=input("Ingrese frase: ")
print("Frase:",n)
a=0
b=[]
c=0
d=0
e=0
for i in range(0,len(n)):
    for k in range(0,10):
        if n[i]==str(k):
            a=a+1
            b.append(k)
for i in range(0,len(n)):
    for k in range(65,91):
        if n[i]==chr(k):
            c+=1
for i in range(0,len(n)):
    for k in range(97,123):
        if n[i]==chr(k):
            d+=1
print("Mayusculas:",c)
print("Minusculas:",d)
print("Caracteres especiales:",len(n)-c-d-a)
print("Suma numeros:",end=" ")
for l in range(0,len(b)):
    e+=b[l]
print(e)
print("String numeros:",end=" ")
for l in range(0,len(b)):
    print(b[l],end="")