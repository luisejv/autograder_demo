import random
x=int(input("Ingrese numero de filas: "))
y=int(input("Ingrese numero de columnas: "))
def imprimirmatriz(n,m):
    l=""
    x = [[random.randint(0, 9) for i in range(0, m)] for k in range(0, n)]
    print("Matriz original:")
    for i in range(0, n):
        for k in range(0, m):
            print(x[i][k], end=" ")
        print()
    l = ""
    a = 0
    print("Matriz final")
    for i in range(0, n):
        for k in range(0, m):
            if (i + k) % 2 == 0:
                print("@", end=" ")
            else:
                print("*", end=" ")
                a += 1
        print()
    print("Suma de asteriscos:", a)
    return l
print(imprimirmatriz(x,y))