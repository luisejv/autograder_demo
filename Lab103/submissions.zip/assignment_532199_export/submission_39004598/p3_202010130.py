def f(a,b):
    l=""
    c=[]
    f=[]
    for i in range(0,len(a)):
        c.append(a[i])
    for i in range(0,len(b)):
        f.append(b[i])
    print("Numeros:", end=" ")
    for i in range(0, len(a)):
        print(a[i], end=",")
    print()
    print("Palabras:", end=" ")
    for i in range(0, len(b)):
        print(b[i], end=",")
    print()
    print("Tamaño numeros:", end=" ")
    for i in range(0, len(a)):
        print(len(str(a[i])), end=",")
    print()
    print("Tamaño palabras:", end=" ")
    for i in range(0, len(b)):
        print(len(b[i]), end=",")
    d = 0
    print()
    for i in range(1, len(a)):
        if a[i] > a[i - 1] and a[i] > d:
            d = a[i]
    for i in range(0, len(c)):
        if c[i] == d:
            del a[i]
    d = 0
    for i in range(1, len(b)):
        if len(b[i]) > len(b[i - 1]) and len(b[i]) > d:
            d = len(b[i])
    e = d
    for i in range(len(f) - 1, -1, -1):
        if len(f[i]) == e:
            del b[i]
    print("Lista tamaño:", end=" ")
    for i in range(0, len(a)):
        print(len(str(a[i])), end=",")
    for i in range(0, len(b)):
        print(len(b[i]), end=",")
    return l
a=[]
b=[]
for i in range(1,6):
    n=int(input("Ingrese valor para lista numeros: "))
    while n>=1000:
        print("¡Máximo tres cifras!")
        n=int(input("Ingrese valor para lista numeros: "))
    a.append(n)
for i in range(1,6):
    n=input("Ingrese valor para lista palabras: ")
    while len(n)>9:
        print("¡Máximo nueve caracteres!")
        n=input("Ingrese valor para lista palabras: ")
    b.append(n)
print(f(a,b))