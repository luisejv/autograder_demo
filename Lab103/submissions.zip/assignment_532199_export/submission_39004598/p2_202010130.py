import random
n=input("Ingrese nombre del usuario: ")
m=input("Ingrese preferencia (especial o numeros): ")
def f(x,y):
    z=""
    if y=="numeros":
        l = [random.randint(0, 9) for i in range(1, len(x))]
        for i in range(0, (len(x) * 2) - 1):
            if i % 2 == 0:
                print(x[int(i / 2)], end="")
            else:
                print(l[int((i - 1) / 2)], end="")
    elif y=="especial":
        l = ["@" for i in range(1, len(x))]
        for i in range(0, (len(x) * 2) - 1):
            if i % 2 == 0:
                print(x[int(i / 2)], end="")
            else:
                print(l[int((i - 1) / 2)], end="")
    return z
print("Su nombre sera:",end="")
print(f(n,m))