
def nombre(lista,preg):
    import random
    for i in range(len(n)):
        lista.append(n[i])
    if(preg=="numeros"):
        for i in range(len(lista)+3):
            x = random.randint(0,9)
            if (i%2!=0):
                lista.insert(i,x)

    if(preg == "especial"):
        for i in range(len(lista)+3):
            if i % 2 != 0:
                lista.insert(i,"@")
    return lista

n = input("Cual es tu nombre: ")
lista = [ ]
preg = input("Deseas que tu nombre tenga numeros o carácteres especiales: ")

y = nombre(lista,preg)
for k in (y):
    print(k,end="")