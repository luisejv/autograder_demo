c1 = 0
c2 = 0
numeros = []
palabras = []
while(c1<5):
    n = input("Ingresa valor para la lista números: ")
    while(len(n)>3):
        n = input("Ingresa valor para la lista números: ")
    numeros.append(n)
    c1 = c1+ 1

while(c2<5):
    pal = input("Ingrese valor para lista palabras: ")
    palabras.append(pal)
    c2 = c2 + 1
def funcion(numeros,palabras):
    tamaño1 =[]
    tamaño2 = []

    for i in numeros:
        tamaño1.append(len(i))
    for j in palabras:
        tamaño2.append(len(j))

    print(tamaño1)
    print(tamaño2)
    for i in tamaño1:
        max1 = max(tamaño1)
        if(i==max1):
            tamaño1.remove(i)
    for j in tamaño2:
        max2 = max(tamaño2)
        if (j == max2):
            tamaño2.remove(j)

    lista_tamaño = tamaño1 + tamaño2
    return(lista_tamaño)

x = funcion(numeros,palabras)
print(x)




















