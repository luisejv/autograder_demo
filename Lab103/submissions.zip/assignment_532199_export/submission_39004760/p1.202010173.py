n = input("Ingrese una frase: ")
lista = []
mayusculas = 0
minusculas = 0
letras = 0
ABC = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","Ñ","P","Q","R","S","T","U","V","W","X","Y","Z"]
abc = ["a","b","c","d","e","f","g","h","i","J","k","l","m","n","ñ","o","p","q","r","s","t","u","v","w","x","y","z"]
num = ["1","2","3","4","5","6","7","8","9","0"]
numeros = 0
suma = []
caracteres = 0
for i in range(len(n)):
    lista.append(n[i])

for i in lista:
    if(i == i.upper() and i!=" "):
        if i not in num:
             mayusculas = mayusculas + 1
    elif(i == i.lower()and i!= " "):
        if i not in num:
             minusculas = minusculas + 1
    if i in num:
        numeros = numeros + 1
        i = int(i)
        suma.append(i)

    else:
        if i not in abc:
            if i not in ABC:
                if i not in num:
                     caracteres = caracteres + 1





print("Mayusculas:" ,mayusculas)
print("Minusculas:",minusculas)
print("Caracteres especiales:",caracteres)
print(sum(suma))

for k in suma:
    print(k,end="")