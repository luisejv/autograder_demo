n = int(input("Ingresa el numero de filas: "))
m = int(input("Ingresa el numero de columnas: "))
while m<1:
    m = int(input("Ingresa el numero de columnas: "))

import random
matriz = []
def imprimirmatriz (matriz):
    import random
    for i in range(n):
        matriz.append([])
        for j in range(m):
            matriz[i].append([random.randint(0,10)])
    return(matriz)

print(imprimirmatriz(matriz), end="")
