
#num=[3,44,55,444,344]
#string=["a","bb","ccc","ddd","eeee"]

num=[]
string=[]
cont=0

while True:
    if cont==5:
        break
    valor = int(input("Ingrese valor para lista numeros :"))
    n=str(valor)
    while len(n) > 9:
        valor = int(input("Ingrese valor para lista numeros :"))
        n = str(valor)
    num.append(valor)
    cont+=1

print(num)

cont=0

while True:
    if cont==5:
        break
    valor= str(input("Ingrese valor para lista palabras :"))
    while len(valor) > 9:
        valor = str(input("Ingrese valor para lista palabras :"))
    string.append(valor)
    cont+=1

print(string)

print("Tamano numeros :",end=" ")
for i in range(5):
    if i == 4:
        print(num[i])
    else:
        print(num[i], end=",")


print("Tamano palabras :",end=" ")
for i in range(5):
    if i == 4:
        print(string[i])
    else:
        print(string[i], end=",")

max = len(str(num[0]))
for j in range(5):
    if max < len(str(num[j])):
        max = len(str(num[j]))

for k in range(5):
    if max == len(str(num[k])):
        num.pop(k)


max = len(string[0])
for a in range(5):
    if max < len(string[a]):
        max = len(string[a])

for b in range(5):
    if max == len(string[b]):
        string.pop(b)



