
import random

usuario=str(input("Ingrese nombre del usuario :"))
preferencia=str(input("Ingrese preferencia ( especial o numeros ):"))
apodo=[]
rand=[]
final=""


for i in range(len(usuario)):
    string = usuario[i]
    apodo.append(string)

print("Su nombre sera:",end=" ")

for k in range(len(usuario)-1):
    a=random.randrange(10)
    rand.append(a)


if preferencia == "numeros" or preferencia == "":
    for j in range(len(apodo)):
        if j == len(apodo) -1:
            final += apodo[j]
        else:
            final += apodo[j]
            final += str(rand[j])

elif preferencia == "especial":
    for j in range(len(apodo)):
        if j == len(apodo) -1:
            final += apodo[j]
        else:
            final += apodo[j]
            final += "@"


print("Su nombre sera :",final)

