num=[11,22,333333,42,533333]
string=["a","bb","ccc","dddd","eeee"]

max = len(str(num[0]))
for j in range(5):
    if max < len(str(num[j])):
        max = len(str(num[j]))

for k in range(5):
    if max == len(str(num[k])):
        num.pop(k)

print(num)

max = len(string[0])
for a in range(5):
    if max < len(string[a]):
        max = len(string[a])

for b in range(5):
    if max == len(string[b]):
        string.pop(b)

print(string)