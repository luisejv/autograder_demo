
frase=str(input("Ingrese frase :"))

mayus=0
minus=0
esp=0
num=[]
sum=0
str_num=""

import string

alphabet_string1 = string.ascii_uppercase

mayusculas= list(alphabet_string1)

alphabet_string2 = string.ascii_lowercase

minusculas= list(alphabet_string2)

numeros=["1","2","3","4","5","6","7","8","9","0"]

caracteres=[" ","!","@","#","$","%","^","&","*","(",")","[" ,"]" ,"{" ,"}",";",":",",",".","/","<",">","?","|","`","~","-","=" ,"_" ,"+"]

for i in range(len(frase)):
    if frase[i] in mayusculas:
        mayus += 1
    elif frase[i] in minusculas:
        minus += 1
    elif frase[i] in caracteres:
        esp += 1
    elif frase[i] in numeros:
        num.append(frase[i])
        sum += int(frase[i])

for j in range(len(num)):
    str_num += num[j]

print("Frase :",frase)
print("Mayusculas :", mayus)
print("Minusculas :", minus)
print("Caracteres especiales :",esp)
print("Suma numeros :",sum)
print("String numeros :",str_num)






