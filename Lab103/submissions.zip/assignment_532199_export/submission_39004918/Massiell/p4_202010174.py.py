from random import randint

matriz=[]
def imprimir(matriz):
    for i in range(filas):
        for j in range(columnas):
            print(matriz[i][j], end=" ")
        print()
    matriz =[[randint(0,10) for i in range(filas)] for j in range(columnas)]


filas=int(input("Ingrese numero de filas :"))
columnas=int(input("Ingrese numero de columnas :"))

imprimir(matriz)