lista = []
lista1 = []
lista2 = []
for x in range(5):
    num = int(input("Ingrese valor para lista numeros :"))
    lista.append(num)

for i in range(5):
    pal = input("Ingrese valor para lista palabras  :")
    lista1.append(pal)

for j in lista1:
    len(j)
    name = lista2.append(len(j))
    print(name)

print("Numeros :", ",".join(map(str, lista)))
print("Palabras :", ",".join(lista1))
