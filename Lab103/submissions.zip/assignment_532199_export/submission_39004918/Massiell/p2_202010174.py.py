from random import randint


def nombre():
    nomb = input("Ingrese nombre del usuario :")
    opcion = input("Ingrese preferencia ( especial o numeros ) :  ")
    if opcion == "especial":
        list(nomb)
        for x in range(0, len(nomb), 2):
            nomb.insert(randint(0, 10))
            "".join(nomb)
            print(nomb)
            return nomb




print(nombre())
