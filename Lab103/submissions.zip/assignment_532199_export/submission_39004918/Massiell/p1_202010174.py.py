frase = input("Ingrese frase:  ")
print("Frase:", frase)
con = {"MAY": 0}
cont = {"MIN": 0}

suma = 0

for x in frase:
    if x.isupper():
        con["MAY"] += 1
    elif x.islower():
        cont["MIN"] += 1

print("Mayuscula", con)
print("Minuscula", cont)

for i in frase.split():
    if i.isdigit():
        suma = sum(i)
        print("String números:", suma)
        print("String números:", i)
